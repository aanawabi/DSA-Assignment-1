#include<iostream>
using namespace std;

// Class representing a node (i.e., a process)
class Process {
public:
    string process_id;        
    int execution_time;       
    int remaining_time;       
    Process *next;            

    // Default constructor
    Process() {
        process_id = "";
        execution_time = 0;
        remaining_time = 0;
        next = NULL;
    }

    // Parameterized constructor
    Process(string process_id, int execution_time, int remaining_time) {
        this->process_id = process_id;
        this->execution_time = execution_time;
        this->remaining_time = remaining_time;
        this->next = NULL;
    }
};

// Function to add the first process to the circular linked list
Process* add_to_empty(string p_id, int exec_time, int remaining_time) {
    Process* temp = new Process(p_id, exec_time, remaining_time);
    temp->next = temp;  // Circular link to itself
    return temp;
}

// Function to add a process at the end of the list
Process* add_at_end(Process* tail, string p_id, int exec_time, int remaining_time) {
    Process* ptr = new Process(p_id, exec_time, remaining_time);
    ptr->next = tail->next;  
    tail->next = ptr;        
    tail = ptr;    // New node becomes the tail
    return tail;
}

// Function to delete a specific process (node) from the circular linked list
Process* delete_a_node(Process* tail, Process* target) {
    if (tail == NULL) {
        return NULL;  // Empty list
    }

    Process* curr = tail->next;  // Start from the head
    Process* prev = tail;

    // Search for the process to delete
    do {
        if (curr == target) {
            break;
        }
        prev = curr;
        curr = curr->next;
    } while (curr != tail->next);

    if (curr == target) {
        if (curr == tail && curr == tail->next) {
            // In the case of a single node
            delete curr;
            return NULL;
        }
        if (curr == tail) {
            tail = prev;  // Update tail if deleting the current tail
        }
        prev->next = curr->next;
        delete curr;
    }
    return tail;
}

// Function to print the circular linked list
void print_list(Process* tail) {
    if (tail == NULL) {
        cout << "List is Empty";
        return;
    }

    Process* ptr = tail->next;
    do {
        cout << ptr->process_id << " (Remaining: " << ptr->remaining_time << ")";
        if (ptr->next != tail->next) cout << ", ";  
        ptr = ptr->next;
    } while (ptr != tail->next);
    cout << endl;
}

int main() {

    int TIME_PER_CYCLE = 3;  // CPU time per cycle

    // Initialize the circular linked list with initial processes
    Process* tail = add_to_empty("P1", 15, 15);  
    tail = add_at_end(tail, "P2", 7, 7);         
    tail = add_at_end(tail, "P3", 12, 12);         

    Process *ptr = tail->next;
    
    cout << "Initial Processes: [";
    do {
        // Display initial state  
        cout << "(" << ptr->process_id << ", " << ptr->remaining_time << ")";
        if (ptr->next != tail->next) cout << ", ";
        ptr = ptr->next;
    } while (ptr != tail->next);

    cout << "]" << endl;
    cout << "CPU Time per Process per Cycle: " << TIME_PER_CYCLE << endl;

    ptr = tail->next;  // Start with the first process (P1)
    int cycle = 1;

// process scheduling cycle
while (tail != NULL) {
    cout << "Cycle " << cycle << ": ";

    Process* current = tail->next;  // Start with the head (tail->next)
    Process* previous = tail;       // To keep track of the previous process

    do {
        // Reduce remaining time
        current->remaining_time = max(current->remaining_time - TIME_PER_CYCLE, 0);

        // Check if the current process has completed
        if (current->remaining_time == 0) {
            cout << current->process_id << " Completes, ";

            // Store the process to be deleted
            Process* to_delete = current;

            // Move to the next process before deletion
            current = current->next;

            // If the tail is being deleted, update the tail
            if (to_delete == tail) {
                tail = previous;
            }

            // Delete the completed process
            tail = delete_a_node(tail, to_delete);

            // If tail becomes NULL after deletion, all processes are done
            if (tail == NULL) {
                cout << "All processes complete." << endl;
                return 0;
            }
        } else {
            // If not deleting, just move to the next process
            previous = current;
            current = current->next;
        }

    } while (current != tail->next);  // Continue until we loop back to the start

    // Print the state of the system after the cycle
    print_list(tail);
    cycle++;

    // Optional task: add a new process P4 after cycle 2
    if (cycle == 3) {
        cout << "New process arrives: P4 (Remaining: 3)" << endl;
        tail = add_at_end(tail, "P4", 3, 3);  // Add new process P4
    }

    cout << endl;
}


    return 0;
}
