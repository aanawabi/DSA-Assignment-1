#include <iostream>
#include <random>
#include <string>
#include <ctime>
#include <gmp.h>
#include <gmpxx.h>
#include <vector>

using namespace std;

class Node {
public:
    string data;
    Node* next = NULL;

    Node() {
        data = "";
        next = NULL;
    }

    Node(string data) {
        this -> data = data;
        this -> next = NULL; 
    }
};

void add_node_to_end(Node* head, string data) {
    if (head == NULL) {
        cout << "List is empty";
        return;
    }

    Node* ptr = head;
    Node* temp = new Node(data);
    
    while (ptr->next != NULL) {
        ptr = ptr->next;
    }
    ptr->next = temp;
}

/*
void print_data(Node* head) {
    if (head == NULL) {
        cout << "List is empty";
        return;
    }
    
    Node* ptr = head;
    while (ptr != NULL) {
        cout << ptr->data << endl;
        ptr = ptr->next;
    }
}
*/

void create_linked_list(Node* head, string number) {
    for (size_t i = 0; i < number.length(); i += 20) {
        string part = number.substr(i, 20); // Extract up to 20 digits
        add_node_to_end(head, part);
    }
    
}

string generate_random_number() {
    string number;
    mt19937 random(static_cast<int>(time(0)));
    uniform_int_distribution<int> first_digit(1, 9);
    number += to_string(first_digit(random));
    uniform_int_distribution<int> rest_digits(0, 9);
    for (int i = 0; i < 308; ++i) {
        number += to_string(rest_digits(random));
    }
    return number;
}

string concatenate_number(Node* head) {
    string full_number = "";
    Node* ptr = head;
    while (ptr != NULL) {
        full_number += ptr->data;
        ptr = ptr->next;
    }
    return full_number;
}

// Manual modular exponentiation
mpz_class mod_exp(mpz_class base, mpz_class exp, mpz_class mod) {
    mpz_class result = 1;
    base = base % mod;

    while (exp > 0) {
        if (exp % 2 == 1) { // If exp is odd
            result = (result * base) % mod;
        }
        exp = exp >> 1; // Divide exp by 2
        base = (base * base) % mod; // Square the base
    }
    return result;
}

// Miller-Rabin primality test
bool miller_rabin(const mpz_class& n, int k) {
    if (n < 2) return false;
    if (n != 2 && n % 2 == 0) return false;

    mpz_class d = n - 1;
    int r = 0;

    while (d % 2 == 0) {
        d /= 2;
        r++;
    }

    for (int i = 0; i < k; i++) {
        mpz_class a = 2 + mpz_class(rand()) % (n - 4);
        mpz_class x = mod_exp(a, d, n); // Using manual mod_exp

        if (x == 1 || x == n - 1) continue;

        bool found = false;
        for (int j = 0; j < r - 1; j++) {
            x = (x * x) % n; // x = x^2 mod n
            if (x == n - 1) {
                found = true;
                break;
            }
        }
        if (!found) return false; // Composite
    }

    return true; // Probably prime
}

// Function to find primes less than the big number
vector<int> find_small_primes(const mpz_class& big_number) {
    vector<int> primes;
    for (int num = 2; num <= 100; ++num) {  // Adjust this range as per need
        bool prime = true;
        for (int i = 2; i * i <= num; ++i) {
            if (num % i == 0) {
                prime = false;
                break;
            }
        }
        if (prime) {
            primes.push_back(num);
        }
    }
    return primes;
}

int main() {
    string number = generate_random_number();
    // int small_number = 17;
    // cout << "Input:  " << small_number << endl;

    cout << "Input: A 1024-bit number represented as: " << number << endl;

    Node* head = new Node();
    create_linked_list(head, number);
    
    string full_number = concatenate_number(head);
    mpz_class big_number(full_number);
    
    // Finding primes smaller than the big number
    vector<int> primes = find_small_primes(big_number);
    
    // Print the primes
    cout << "Smaller primes: [";
    for (size_t i = 0; i < primes.size(); ++i) {
        cout << primes[i];
        if (i < primes.size() - 1) cout << ", ";
    }
    cout << "...]" << endl;

    int k = 10; // Number of iterations
    bool is_prime = miller_rabin(big_number, k);
    
    if (is_prime) {
        cout << "Output: True" << endl;
    } else {
        cout << "Output: False" << endl;
    }

    // Free linked list memory
    Node* current = head;
    while (current != nullptr) {
        Node* next_node = current->next;
        delete current;
        current = next_node;
    }
    
    return 0;
}
